public abstract class Shape {
    public abstract double surface_area();
    public abstract double volume();

    // Run this file directly in VS Code.
    public static void main(String[] args) {
        ShapeArray.main(args);
    }
}

class Sphere extends Shape {
    private final double radius;

    public Sphere(double radius) {
        this.radius = radius;
    }

    @Override
    public double surface_area() {
        return 4 * Math.PI * radius * radius;
    }

    @Override
    public double volume() {
        return (4.0 / 3.0) * Math.PI * radius * radius * radius;
    }

    @Override
    public String toString() {
        return String.format("Sphere (radius %.2f): Surface Area = %.2f, Volume = %.2f",
                radius, surface_area(), volume());
    }
}

class Cylinder extends Shape {
    private final double radius;
    private final double height;

    public Cylinder(double radius, double height) {
        this.radius = radius;
        this.height = height;
    }

    @Override
    public double surface_area() {
        return 2 * Math.PI * radius * (radius + height);
    }

    @Override
    public double volume() {
        return Math.PI * radius * radius * height;
    }

    @Override
    public String toString() {
        return String.format("Cylinder (radius %.2f, height %.2f): Surface Area = %.2f, Volume = %.2f",
                radius, height, surface_area(), volume());
    }
}

class Cone extends Shape {
    private final double radius;
    private final double height;

    public Cone(double radius, double height) {
        this.radius = radius;
        this.height = height;
    }

    @Override
    public double surface_area() {
        double slantHeight = Math.sqrt(radius * radius + height * height);
        return Math.PI * radius * (radius + slantHeight);
    }

    @Override
    public double volume() {
        return Math.PI * radius * radius * height / 3.0;
    }

    @Override
    public String toString() {
        return String.format("Cone (radius %.2f, height %.2f): Surface Area = %.2f, Volume = %.2f",
                radius, height, surface_area(), volume());
    }
}

class ShapeArray {
    public static void main(String[] args) {
        Shape[] shapeArray = {
            new Sphere(3.0),
            new Cylinder(2.0, 5.0),
            new Cone(4.0, 6.0)
        };

        for (Shape shape : shapeArray) {
            System.out.println(shape.toString());
        }
    }
}
